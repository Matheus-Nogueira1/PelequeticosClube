## Dados de um Combatente - Estrutura base para inimigos, jogadores e NPCs
## Em OBLIVIO: Estresse acumula de 0 até o LIMITE (não é HP)
## Quando região atinge seu limite, fica ESGOTADA (fadiga)

class_name CombatenteData
extends RefCounted

## Regiões do corpo
const REGIOES = ["Torso", "Braço Direito", "Braço Esquerdo", "Perna Direita", "Perna Esquerda"]

## Atributos do combatente
var nome: String
var tipo: String  # "jogador", "inimigo", "npc"

## Atributos Fixos OBLIVIO (5 pilares)
var atributo_carne: int = 1              # Saúde, vigor e integridade física
var atributo_forca: int = 1              # Potência muscular e capacidade de danificar
var atributo_mente: int = 1              # Aptidão e resiliência intelectual
var atributo_fuga: int = 1               # Agilidade e velocidade de reação
var atributo_determinacao: int = 1       # Resiliência e inteligência emocional

## Atributos Mutáveis (derivados dos Fixos: (fixo1 + fixo2) / 2, arredondado para baixo)
## - Fôlego = (Carne + Determinação) / 2
## - Dano = (Força + Carne) / 2
## - Coragem = (Determinação + Mente) / 2
## - Proteção = (Carne + Fuga) / 2
## - Velocidade = (Fuga + Determinação) / 2
var atributo_folego: int = 1             # Capacidade de recuperação durante ação
var atributo_dano: int = 1               # Intensidade de dano
var atributo_coragem: int = 1            # Firmeza e resiliência emocional
var atributo_protecao: int = 1           # Dificuldade de ser acertado
var atributo_velocidade: int = 1         # Velocidade de movimento


## Dados de combate
var arma_equipada: String = ""
var dano_arma: int = 1
var defesa_base: int = 1
var iniciativa: int = 0
var status: Array[String] = []
var desmaiado: bool = false
var reducao_protecao_temporaria: int = 0
var bonus_duelo_protecao := 0
var analisado_por_duelo := false

# Quem causou o último dano após quebrar a proteção
var atacante_que_quebrou_protecao: String = ""


## ESTRESSE POR REGIÃO (métrica principal em OBLIVIO)
## Começa com 0 e acumula até o LIMITE
## Quando atinge limite, região fica ESGOTADA (fadiga)
var estresse_por_regiao: Dictionary = {
	"Torso": {"atual": 0, "limite": 6},
	"Braço Direito": {"atual": 0, "limite": 3},
	"Braço Esquerdo": {"atual": 0, "limite": 3},
	"Perna Direita": {"atual": 0, "limite": 3},
	"Perna Esquerda": {"atual": 0, "limite": 3}
}

## Pontos de Ação
var pontos_acao_atuais: int = 3
var pontos_acao_maximos: int = 3

## CONHECIMENTOS (Perícias OBLIVIO)
## Nível de treino em cada um dos 10 Conhecimentos (sem máximo)

## Origem das especializações
const ORIGEM_PAPEL: String = "papel"
const ORIGEM_MENTE: String = "mente"
const ORIGEM_PROGRESSAO: String = "progressao"

## Origem de cada conhecimento especializado.
## Chave: nome do conhecimento; valor: origem.
var conhecimentos_origem: Dictionary = {}

## Conhecimentos que podem receber treinamento por permissão explícita.
## Usado para exceções de personagem e progressões autorizadas.
var conhecimentos_treino_permitido: Array[String] = []

var conhecimentos_treino: Dictionary = { 
	"Bandidagem": 0,    # Delitos, furtividade de crimes
	"Duelo": 0,         # Estratégia marcial, brechas em defesa
	"Emocional": 0,     # Autocontrole, gestão de sentimentos
	"Esforço": 0,       # Físico desgastante, resistência corporal
	"Místico": 0,       # Sobrenatural, artes arcanas, seres outros
	"Mundo": 0,         # Natureza, animais, sobrevivência
	"Rastro": 0,        # Percepção, detalhes ocultos, sensoriais
	"Reflexos": 0,      # Esqu	iva, corporais rápidos, movimento
	"Saber": 0,         # Memória, estudos, conhecimento geral
	"Social": 0         # Persuasão, manipulação emocional, charisma
}

## Conhecimentos Especializados (persona tem 3 + Mente/2 especializados)
## Ao testar especializado, soma +2 ao resultado
var conhecimentos_especializados: Array[String] = []


## Habilidades especiais
var habilidades: Array[String] = []

## Itens
var inventario: Array[String] = []


## Sistema de Fardos (Dark Souls curses) - Aplicados quando Torso atinge limite
var fardos: Array = []                           # Array de Fardo aplicados
var regioes_perdidas: Array[String] = []       # Membros perdidos por Guilhotina
var numero_desmaios_total: int = 0             # Total de vezes que atingiu limite de Torso
var limite_estresse_maximo_reducao: int = 0    # Redução permanente por Mal das Pernas

## Sistema de Próteses - Permitem manter regiões após dano severo
## Chave = nome da região, Valor = Protese object
var proteses: Dictionary = {}                   # Próteses por região
var habilidade_sobrecarga_ativa: bool = false  # Ir Além - permite arriscar múltiplas vezes mesma região

## Flags de efeitos de Fardos
var tem_covardia: bool = false                  # -2x Coragem em testes
var tem_fragilidade: bool = false              # +1D6 dano recebido
var tem_ataque_cardiaco: bool = false          # Risco de morte em próxima vez
var morto: bool = false                         # Flag de morte permanente


## ===== MÉTODOS =====

func _init(p_nome: String, p_tipo: String) -> void:
	nome = p_nome
	tipo = p_tipo
	_calcular_atributos_mutaveis()

## Calcula todos os Atributos Mutáveis baseado nos Atributos Fixos
func _calcular_atributos_mutaveis() -> void:
	atributo_folego = (atributo_carne + atributo_determinacao) / 2
	atributo_dano = (atributo_forca + atributo_carne) / 2
	atributo_coragem = (atributo_determinacao + atributo_mente) / 2
	atributo_protecao = (atributo_carne + atributo_fuga) / 2
	atributo_velocidade = (atributo_fuga + atributo_determinacao) / 2

## Atualiza atributo fixo e recalcula os mutáveis
func atualizar_atributo_fixo(atributo: String, valor: int) -> void:
	match atributo.to_lower():
		"carne": atributo_carne = valor
		"forca": atributo_forca = valor
		"mente": atributo_mente = valor
		"fuga": atributo_fuga = valor
		"determinacao": atributo_determinacao = valor
	_calcular_atributos_mutaveis()

## ===== CONHECIMENTOS (PERÍCIAS OBLIVIO) =====

## Conta quantas especializações pertencem a uma origem.
func contar_especializacoes_por_origem(origem: String) -> int:
	var total: int = 0

	for conhecimento in conhecimentos_especializados:
		if conhecimentos_origem.get(conhecimento, "") == origem:
			total += 1

	return total


## Verifica se um conhecimento é especializado.
func tem_especializacao(conhecimento: String) -> bool:
	return conhecimento in conhecimentos_especializados


## Adiciona uma especialização durante a criação inicial.
## O limite é validado separadamente para Papel e Mente.
func adicionar_especializacao_inicial(
	conhecimento: String,
	origem: String
) -> bool:
	if not conhecimentos_treino.has(conhecimento):
		return false

	if tem_especializacao(conhecimento):
		return false

	if origem == ORIGEM_PAPEL:
		if contar_especializacoes_por_origem(ORIGEM_PAPEL) >= 3:
			return false
	elif origem == ORIGEM_MENTE:
		var limite_mente: int = int(floor(float(atributo_mente) / 2.0))
		if contar_especializacoes_por_origem(ORIGEM_MENTE) >= limite_mente:
			return false
	else:
		return false

	conhecimentos_especializados.append(conhecimento)
	conhecimentos_origem[conhecimento] = origem
	return true


## Adiciona uma especialização por progressão.
## O bônus de treinamento só é liberado se explicitamente autorizado.
func adicionar_especializacao(
	conhecimento: String,
	permite_treinamento: bool = false
) -> bool:
	if not conhecimentos_treino.has(conhecimento):
		return false

	if tem_especializacao(conhecimento):
		return false

	conhecimentos_especializados.append(conhecimento)
	conhecimentos_origem[conhecimento] = ORIGEM_PROGRESSAO

	if permite_treinamento:
		if conhecimento not in conhecimentos_treino_permitido:
			conhecimentos_treino_permitido.append(conhecimento)

	return true


## Remove especialização e os dados de treinamento associados.
func remover_especializacao(conhecimento: String) -> void:
	if not tem_especializacao(conhecimento):
		return

	conhecimentos_especializados.erase(conhecimento)
	conhecimentos_origem.erase(conhecimento)
	conhecimentos_treino_permitido.erase(conhecimento)

	if conhecimentos_treino.has(conhecimento):
		conhecimentos_treino[conhecimento] = 0

## Verifica se o treinamento pode conceder bônus.
## Especializações adicionais pela Mente recebem bônus automaticamente.
## Papel e progressão exigem permissão explícita.
func pode_receber_bonus_treinamento(conhecimento: String) -> bool:
	if not tem_especializacao(conhecimento):
		return false

	var origem: String = conhecimentos_origem.get(conhecimento, "")

	if origem == ORIGEM_MENTE:
		return true

	return conhecimento in conhecimentos_treino_permitido


## Calcula o bônus total de um teste de conhecimento.
## Especialização: +2.
## Treinamento permitido: +1 por nível.
func calcular_bonus_conhecimento(conhecimento: String) -> int:
	if not tem_especializacao(conhecimento):
		return 0

	var bonus: int = 2

	if pode_receber_bonus_treinamento(conhecimento):
		bonus += obter_treino_conhecimento(conhecimento)

	return bonus


## Remove treinamentos que não podem conceder bônus.
func limpar_treinamentos_invalidos() -> void:
	for conhecimento in conhecimentos_treino.keys():
		if not pode_receber_bonus_treinamento(conhecimento):
			conhecimentos_treino[conhecimento] = 0


## Retorna nível de treino em um conhecimento.
func obter_treino_conhecimento(conhecimento: String) -> int:
	return int(conhecimentos_treino.get(conhecimento, 0))

## Aumenta treinamento apenas quando a regra permite.
func aumentar_treino_conhecimento(
	conhecimento: String,
	quantidade: int = 1
) -> void:
	if quantidade <= 0:
		return

	if not pode_receber_bonus_treinamento(conhecimento):
		return

	if conhecimentos_treino.has(conhecimento):
		conhecimentos_treino[conhecimento] += quantidade

## ===== VERIFICAÇÃO DE STATUS =====

## Verifica se combatente ainda está consciente (Apenas o Torso)
func esta_consciente() -> bool:
	return not desmaiado

## Verifica se combatente desmaiou (TODAS regiões esgotadas)
func esta_desmaiado() -> bool:
	return not esta_consciente()

## Verifica se região específica está esgotada (estresse >= limite)
func regiao_esgotada(regiao: String) -> bool:
	if not estresse_por_regiao.has(regiao):
		return false
	var estresse = estresse_por_regiao[regiao]
	return estresse["atual"] >= estresse["limite"]

## Verifica se região ainda pode ser arriscada (não esgotada)
func regiao_pode_ser_arriscada(regiao: String) -> bool:
	return not regiao_esgotada(regiao)

## ===== APLICAÇÃO DE EFEITOS =====

## Aplica estresse a uma região (métrica principal em OBLIVIO)
## Se superar limite, transborda para torso (exceto se for torso)
# REGRA OBLIVIO: Dano que supera limite transborda para torso
func aplicar_estresse(regiao: String, estresse_quantidade: int) -> Dictionary:
	var resultado: Dictionary = {}
	if not estresse_por_regiao.has(regiao):
		return {}
	var regiao_stress = estresse_por_regiao[regiao]
	regiao_stress["atual"] += estresse_quantidade
	# Torso
	if regiao == "Torso":
		if regiao_stress["atual"] >= regiao_stress["limite"]:
			regiao_stress["atual"] = regiao_stress["limite"]
			if not desmaiado:
				desmaiado = true
				resultado = processar_limite_torso()
				
				
		return resultado
	# Regiões normais - CAP no limite (não marca como perdida permanentemente)
	if regiao_stress["atual"] >= regiao_stress["limite"]:
		regiao_stress["atual"] = regiao_stress["limite"]
		resultado = {
			"regiao_esgotada": true,
			"regiao": regiao,
			"mensagem": "%s não pode mais ser arriscado." % regiao
		}
		return resultado
		# Apenas bloqueia seleção enquanto esgotada - pode recuperar depois
	
	var excesso = regiao_stress["atual"] - regiao_stress["limite"]
	if excesso > 0:
		regiao_stress["atual"] = regiao_stress["limite"]
		var torso_stress = estresse_por_regiao["Torso"]
		torso_stress["atual"] += excesso
		
		if torso_stress["atual"] >= torso_stress["limite"]:
			torso_stress["atual"] = torso_stress["limite"]
			resultado = processar_limite_torso()
			
	return resultado

## ===== CÁLCULOS =====
func calcular_dano_ataque() -> int:
	var dano = atributo_dano
	if arma_equipada != "":
		dano += ArmaData.rolar_dano_arma(
			arma_equipada
		)
	return dano
## Retorna estresse total (soma de todas regiões)
func get_estresse_total() -> int:
	var total = 0
	for regiao_est in estresse_por_regiao.values():
		total += regiao_est["atual"]
	return total

## Retorna limite de estresse total
func get_limite_estresse_total() -> int:
	var total = 0
	for regiao_est in estresse_por_regiao.values():
		total += regiao_est["limite"]
	return total

## Retorna porcentagem de fadiga geral (0-100%)
func get_porcentagem_fadiga() -> float:
	var total = get_estresse_total()
	var limite = get_limite_estresse_total()
	if limite == 0:
		return 0.0
	return (float(total) / float(limite)) * 100.0

## Retorna quantas regiões estão esgotadas
func contar_regioes_esgotadas() -> int:
	var count = 0
	for regiao in REGIOES:
		if regiao_esgotada(regiao):
			count += 1
	return count

func obter_protecao_atual() -> int:
	return max(
		0,
		atributo_protecao
		- reducao_protecao_temporaria
		- bonus_duelo_protecao
	)
## ===== PA (PONTOS DE AÇÃO) =====

## Restaura PA no início do turno
func restaurar_pontos_acao() -> void:
	pontos_acao_atuais = pontos_acao_maximos

## Consome PA para uma ação
func consumir_pontos_acao(custo: int) -> bool:
	if pontos_acao_atuais >= custo:
		pontos_acao_atuais -= custo
		return true
	return false

## ===== DESMAIOS E FARDOS =====

func processar_limite_torso() -> Dictionary:
	print("=== PROCESSAR LIMITE TORSO ===")
	print(nome)
	print(tipo)
	
	# Inimigos morrem na primeira
	if tipo == "inimigo":
		morto = true
		desmaiado = true
		return {
			"sucesso": true,
			"derrotado": true,
		}

	# Jogadores recebem Fardos
	numero_desmaios_total += 1

	# 3ª desmaio (ou mais) com Ataque Cardíaco = MORTE PERMANENTE
	if numero_desmaios_total >= 3 and tem_ataque_cardiaco:
		morto = true
		desmaiado = true
		return {
			"numero_desmaio": numero_desmaios_total,
			"morto": true,
			"mensagem": "ATAQUE CARDÍACO! %s morreu permanentemente!" % nome
		}

	# Sorteio normal de Fardo
	var novo_fardo = FardoData.sortear_fardo(numero_desmaios_total)
	var resultado_fardo = FardoData.aplicar_fardo(self, novo_fardo)

	return {
		"numero_desmaio": numero_desmaios_total,
		"fardo_aplicado": novo_fardo.nome,
		"resultado_fardo": resultado_fardo,
		"mensagem": "Desmaiou #%d - %s!" % [numero_desmaios_total, novo_fardo.nome]
	}

## Revive um combatente (reduz 1 ponto de Torso para acordar)
func reviver() -> void:
	"""Revive o combatente desmaiado removendo 1 Torso (pode agir novamente)"""
	var torso = estresse_por_regiao["Torso"]
	torso["atual"] = max(0, torso["atual"] - 1)
	desmaiado = false

## Reduz o estresse de uma região (usado por itens como o Frasco Estus)
func aliviar_estresse(regiao: String, quantidade: int) -> void:
	if not estresse_por_regiao.has(regiao):
		return
	var dados: Dictionary = estresse_por_regiao[regiao]
	dados["atual"] = max(0, dados["atual"] - quantidade)

## Descanso: zera o estresse e acorda o combatente ao voltar ao mapa
func recuperar_apos_combate() -> void:
	for regiao in estresse_por_regiao.keys():
		estresse_por_regiao[regiao]["atual"] = 0
	desmaiado = false
	reducao_protecao_temporaria = 0
	bonus_duelo_protecao = 0
	atacante_que_quebrou_protecao = ""
	analisado_por_duelo = false

## Limpa só os efeitos temporários do combate, mantendo o Estresse acumulado
func limpar_efeitos_combate() -> void:
	reducao_protecao_temporaria = 0
	bonus_duelo_protecao = 0
	atacante_que_quebrou_protecao = ""
	analisado_por_duelo = false

## Verifica se personagem está desmaiado (TODAS regiões no limite)
func verificar_desmaio() -> bool:
	"""Apenas verifica, sem aplicar Fardo (use processar_limite_torso() para isso)"""
	return esta_desmaiado()

## ===== COMPATIBILIDADE COM DICIONÁRIO =====

## Converte para Dictionary para compatibilidade
func para_dictionary() -> Dictionary:
	return {
		"nome": nome,
		"tipo": tipo,
		"atributo_carne": atributo_carne,
		"atributo_forca": atributo_forca,
		"atributo_mente": atributo_mente,
		"atributo_fuga": atributo_fuga,
		"atributo_determinacao": atributo_determinacao,
		"atributo_folego": atributo_folego,
		"atributo_dano": atributo_dano,
		"atributo_coragem": atributo_coragem,
		"atributo_protecao": atributo_protecao,
		"reducao_protecao_temporaria": reducao_protecao_temporaria,
		"atacante_que_quebrou_protecao": atacante_que_quebrou_protecao,
		"atributo_velocidade": atributo_velocidade,
		"status": status,
		"estresse_por_regiao": estresse_por_regiao,
		"pontos_acao_atuais": pontos_acao_atuais,
		"pontos_acao_maximos": pontos_acao_maximos,
		"conhecimentos_treino": conhecimentos_treino,
		"conhecimentos_especializados": conhecimentos_especializados,
		"conhecimentos_origem": conhecimentos_origem.duplicate(true),
		"conhecimentos_treino_permitido": conhecimentos_treino_permitido.duplicate(),
		"analisado_por_duelo": analisado_por_duelo,
		"habilidades": habilidades,
		"inventario": inventario,
		"fardos": fardos,
		"regioes_perdidas": regioes_perdidas,
		"numero_desmaios_total": numero_desmaios_total,
		"proteses": proteses,
		"habilidade_sobrecarga_ativa": habilidade_sobrecarga_ativa,
		"morto": morto
	}
## Cria a partir de um Dictionary
static func de_dictionary(dados: Dictionary) -> CombatenteData:
	var nome_temp = "Desconhecido"
	if dados.has("nome"):
		nome_temp = dados["nome"]
	
	var tipo_temp = "npc"
	if dados.has("tipo"):
		tipo_temp = dados["tipo"]
	
	var combatente = CombatenteData.new(nome_temp, tipo_temp)
	
	if dados.has("atributo_carne"):
		combatente.atributo_carne = dados["atributo_carne"]
	if dados.has("atributo_forca"):
		combatente.atributo_forca = dados["atributo_forca"]
	if dados.has("atributo_mente"):
		combatente.atributo_mente = dados["atributo_mente"]
	if dados.has("atributo_fuga"):
		combatente.atributo_fuga = dados["atributo_fuga"]
	if dados.has("atributo_determinacao"):
		combatente.atributo_determinacao = dados["atributo_determinacao"]
	
	if dados.has("atributo_folego"):
		combatente.atributo_folego = dados["atributo_folego"]
	if dados.has("atributo_dano"):
		combatente.atributo_dano = dados["atributo_dano"]
	if dados.has("atributo_coragem"):
		combatente.atributo_coragem = dados["atributo_coragem"]
	if dados.has("atributo_protecao"):
		combatente.atributo_protecao = dados["atributo_protecao"]
	if dados.has("atributo_velocidade"):
		combatente.atributo_velocidade = dados["atributo_velocidade"]
	combatente._calcular_atributos_mutaveis()
	if dados.has("dano_arma"):
		combatente.dano_arma = dados["dano_arma"]
	if dados.has("defesa_base"):
		combatente.defesa_base = dados["defesa_base"]
	if dados.has("iniciativa"):
		combatente.iniciativa = dados["iniciativa"]
	
	if dados.has("estresse_por_regiao"):
		combatente.estresse_por_regiao = dados["estresse_por_regiao"]
	
	if dados.has("pontos_acao_atuais"):
		combatente.pontos_acao_atuais = dados["pontos_acao_atuais"]
	if dados.has("pontos_acao_maximos"):
		combatente.pontos_acao_maximos = dados["pontos_acao_maximos"]
	
	combatente.conhecimentos_especializados.clear()

	for conhecimento in dados.get("conhecimentos_especializados", []):
		var nome_conhecimento: String = str(conhecimento)

		if not combatente.conhecimentos_especializados.has(nome_conhecimento):
			combatente.conhecimentos_especializados.append(nome_conhecimento)
	
		# Restaura as especializações antes de validar os treinamentos.
	combatente.conhecimentos_especializados.clear()

	if dados.has("conhecimentos_especializados"):
		for conhecimento in dados["conhecimentos_especializados"]:
			var nome_conhecimento: String = str(conhecimento)

			if combatente.conhecimentos_treino.has(nome_conhecimento):
				if nome_conhecimento not in combatente.conhecimentos_especializados:
					combatente.conhecimentos_especializados.append(nome_conhecimento)

	# Restaura a origem das especializações.
	if dados.has("conhecimentos_origem"):
		combatente.conhecimentos_origem = dados["conhecimentos_origem"].duplicate(true)
	else:
		# Compatibilidade com saves antigos sem origem registrada.
		for conhecimento in combatente.conhecimentos_especializados:
			combatente.conhecimentos_origem[conhecimento] = CombatenteData.ORIGEM_PROGRESSAO

	# Restaura os conhecimentos autorizados a receber treinamento.
	combatente.conhecimentos_treino_permitido.clear()

	if dados.has("conhecimentos_treino_permitido"):
		for conhecimento in dados["conhecimentos_treino_permitido"]:
			var nome_conhecimento: String = str(conhecimento)

			if combatente.conhecimentos_treino.has(nome_conhecimento):
				if nome_conhecimento not in combatente.conhecimentos_treino_permitido:
					combatente.conhecimentos_treino_permitido.append(nome_conhecimento)

	# Restaura os níveis de treinamento.
	if dados.has("conhecimentos_treino"):
		var treinos_salvos: Dictionary = dados["conhecimentos_treino"]

		for conhecimento in combatente.conhecimentos_treino.keys():
			if treinos_salvos.has(conhecimento):
				combatente.conhecimentos_treino[conhecimento] = int(
					treinos_salvos[conhecimento]
				)

	# Só valida depois de restaurar todos os dados necessários.
	combatente.limpar_treinamentos_invalidos()
	if dados.has("habilidades"):
		combatente.habilidades = dados["habilidades"]
	if dados.has("inventario"):
		combatente.inventario = dados["inventario"]
	if dados.has("numero_desmaios_total"):
		combatente.numero_desmaios_total = dados["numero_desmaios_total"]
	if dados.has("regioes_perdidas"):
		combatente.regioes_perdidas = dados["regioes_perdidas"]
	if dados.has("morto"):
		combatente.morto = dados["morto"]
	if dados.has("desmaiado"):
		combatente.desmaiado = dados["desmaiado"]
	
	return combatente

## ===== SISTEMA DE PRÓTESES =====

## Adiciona uma prótese ao combatente
func adicionar_protese(protese: ProteseData.Protese) -> void:
	proteses[protese.regiao_representada] = protese

## Obtém uma prótese por região
func obter_protese(regiao: String) -> ProteseData.Protese:
	if proteses.has(regiao):
		return proteses[regiao]
	return null

## Verifica se região tem prótese
func tem_protese(regiao: String) -> bool:
	return proteses.has(regiao) and not proteses[regiao].destruida

## Aplica estresse à prótese (retorna excedente)
func aplicar_estresse_protese(regiao: String, quantidade: int) -> int:
	var protese = obter_protese(regiao)
	if protese:
		return protese.sofrer_estresse(quantidade)
	return quantidade

## Recupera estresse da prótese
func recuperar_protese(regiao: String, quantidade: int) -> void:
	var protese = obter_protese(regiao)
	if protese:
		protese.recuperar_estresse(quantidade)
